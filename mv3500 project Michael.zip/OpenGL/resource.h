//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OpenGL.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDR_OPENGLTYPE                  129
#define IDD_ROTATION_DIALOG             130
#define IDD_CONSOLE                     131
#define IDD_JOIN_DIALOG                 134
#define IDC_EDIT_ANGLE1                 1000
#define IDC_EDIT_ANGLE2                 1001
#define IDC_EDIT_ANGLE3                 1002
#define IDC_CONSOLE                     1003
#define ID_IPADD                        1014
#define ID_RESTORE_VIEW                 32771
#define ID_SOLID                        32772
#define ID_WIREFRAME                    32773
#define ID_TOGGLE_LIGHTING              32774
#define ID_TOGGLE_LIGHT0                32775
#define ID_ANIMATION_OFF                32776
#define ID_ANIMATION_ON                 32777
#define ID_ROTATION_DIALOG              32778
#define ID_FLY                          32779
#define ID_STUDY                        32780
#define ID_WALK                         32781
#define ID_PAN                          32782
#define ID_TOGGLE_LIGHT1                32783
#define ID_TOGGLE_LIGHT2                32784
#define ID_COLLISION_ON                 32785
#define ID_COLLISION_OFF                32786
#define ID_HOST                         32787
#define ID_JOIN                         32788
#define ID_DISCONNECT                   32789
#define ID_SINGLE                       32790
#define ID_MULTI                        32791
#define ID_QUIT                         32792

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
